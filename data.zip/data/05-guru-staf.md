# Guru dan Staf SMK TTH (dari website)
## Jabatan
- Waka Kurikulum: Heru Budi, M.PdI
- Waka Kesiswaan: Trustha Widhiatmana, S.Pd
- Waka Sapras & Ketenagaan: Zakiyah Wulansari, M.PdI
- Waka Humas: Muhammad Ibnu Nadhir, S.Pd
- Kaprog TJKT: Aris Suryatno, S.T, M.Pd
- Kepala Tata Usaha: Wicaksono, A.Md
- Tata Usaha: Muhammad Rifai, Adnan
- Keuangan: Siti Marhamah, A.Md
- Kepala Perpustakaan: Nuning Widiastuti, SE
- Guru BK/BKK: Misbahul Asfa, S.Pd; Guru BK: Ahmad Munazil, S.Psi
- K3 RPL: Krisadyani Talentana, S.Kom; K3 Multimedia: Hendra Christanto, S.Pd; K3 TKR: Anjar Wahyudi, S.T, M.Pd
- Laboran: Zaki Hariyadi (TKR), Muhammad Fauzi (Otomotif)
## Guru per bidang
- RPL/PPLG: Rian Kustito S.Pd.Kom; Rini Windarti S.T; Sevilia S.Kom; Faizi Widadi S.Kom; Dian Arif Mahardi Raharjo S.Si
- TKJ: Rozaq Satria Darmawan S.Kom; Sulistiyono S.Kom; Siti Karunia Sari S.Kom; Tri Joko Mulyono S.Kom; Akhmad Fajar S.Kom; Aris Suryatno S.T, M.Pd
- DKV/Multimedia: Yunika Arum Prajanti S.I.Kom; Ristiana Suci Wulandari S.Ds; Mushofa S.Kom; Purnomo Sidi Ario Bimo S.T; Arif Lestiyono S.Kom
- TKR: Dannes Gilang Dikari S.Pd; Hendra Prasetiyo S.T; Setiawan Adi Prihanto S.T; Dimas Yogo Pratomo S.T; Carmadi S.Pd
- Matematika: Kukuh Andri Handono S.Pd; Wendy Kumala Dewi S.Pd; Dwi Murdiyani S.Pd
- Bahasa Inggris: Fita Hayatul Hilmah S.Pd; Sutanti Sri Rahayu S.Pd
- Bahasa Indonesia: Wahyu Setiyanto S.Pd
- Fisika: Sa'ida Ervina S.Pd; Gigih Aji Setiyono S.Si, M.Pd (juga Humas)
- IPA: Farah Mauliya Yusriati S.Pd
- PKn: Ninuk Siswardani S.Pd
- PJOK: Septa Arya Wardana S.Pd
- Kewirausahaan: Liany Wulandani S.Pd
- Agama Kristen: Mistriyanto S.Th
- Lainnya tercantum tanpa jabatan: Ivana Septia Rahaya S.Pd M.Pd; Sidiq Sudrajat Dwi Wibowo S.Psi; Listyorini Dika Utami; Amalia Ulfa Intan Ayu A.Md; Zulfatu Nikmah S.Pd (Guru)
## Catatan
- Kepala sekolah SMK Telekomunikasi Tunas Harapan saat ini adalah Wisnu Handoko, S.T., M.T.
