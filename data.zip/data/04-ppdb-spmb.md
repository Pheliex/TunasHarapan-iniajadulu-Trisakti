# PPDB/SPMB SMK TTH Tahun Pelajaran 2027/2028
- Pendaftaran dibuka: Desember 2026. Untuk siswa kelas IX SMP/MTs/sederajat.
- (Beranda menyebut "PPDB Tahun 2026/2027" sebagai tautan lama; halaman PPDB terbaru: 2027/2028.)
- Jadwal seleksi: Periode I Januari 2027; II Februari 2027; III Maret 2027; IV April 2027; V Mei 2027; VI Juni 2027.

## Persyaratan
- Membayar biaya pendaftaran (nominal tidak tertulis di website)
- Fotokopi rapor semester 1-5
- Fotokopi akta kelahiran
- Pas foto 3x4 sebanyak 5 lembar
- Fotokopi Kartu Keluarga

## Tata Cara
1. Daftar langsung ke sekretariat PPDB di SMK TTH.
2. Kumpulkan dokumen persyaratan ke panitia.
3. Terima bukti pendaftaran.
4. Terima info waktu & tempat tes kesehatan dan wawancara.
5. Ikut tes kesehatan & wawancara sesuai jadwal (wajib didampingi orang tua/wali).
6. Terima pengumuman hasil seleksi & info daftar ulang.

## Materi Wawancara
Biodata calon siswa; bakat dan minat; karakter dan sikap; kesanggupan menaati peraturan sekolah; kesanggupan orang tua/wali membiayai pendidikan.

## Tes Kesehatan
Buta warna; pendengaran; tato, tindik & cacat tubuh; penyakit keturunan (asma, tremor, jantung, dll); ukur tinggi & berat badan.

## Daftar Ulang
Bayar angsuran I biaya Investasi Pendidikan (disepakati sekolah & orang tua) di Ruang Tata Usaha.

## Pendaftaran Online
https://spmb.tunasharapan.info (mengarah ke Google Form). Bisa untuk yang tidak bisa hadir langsung.

## Catatan untuk Chatbot
Nominal biaya pendaftaran, SPP, dan investasi pendidikan TIDAK ada di website. Jangan menebak; arahkan ke telepon (0298) 311391 atau info@tunasharapan.info. Info beasiswa prestasi, potongan SPP, Program Indonesia Pintar disebut ada tanpa rincian.
# Informasi SPMB (Seleksi Penerimaan Murid Baru) 2026/2027

**Jadwal Pendaftaran:**
* Jalur Minat Tahap I: Januari 2026[cite: 8]
* Jalur Minat Tahap II: Februari 2026[cite: 8]
* Jalur Minat Tahap III: Maret 2026[cite: 8]
* Jalur Minat Tahap IV: April 2026[cite: 8]
* Jalur Minat Tahap V: Mei 2026[cite: 8]
* Reguler: Juni 2026[cite: 8]

**Persyaratan Pendaftaran:**
* Biaya pendaftaran Rp. 60.000,-[cite: 8]
* Fotokopi Rapor semester 1-5[cite: 8]
* Fotokopi Akta Kelahiran dan Kartu Keluarga[cite: 8]
* Pas Foto 3x4 sebanyak 2 lembar[cite: 8]

**Proses Seleksi:**
* Meliputi tahap Berkas/Dokumen, Wawancara, dan Kesehatan[cite: 8]
* Pendaftaran online dapat diakses melalui https://spmb.tunasharapan.info[cite: 7]

**Biaya Pendidikan (Periode Januari - April 2026):**
* Partisipasi Pembangunan (PP): Rp. 3.500.000,- (dapat diangsur)[cite: 8]
* SPP: Rp. 250.000,- per bulan[cite: 8]
* Biaya PP dan SPP untuk pendaftaran bulan Mei - Juni akan ditentukan lebih lanjut[cite: 8]

**Biaya Lain-Lain:**
* MPLS: Rp. 70.000,-[cite: 8]
* 7 Seragam (OSIS, Pramuka, Identitas, Batik, Olahraga, Wearpack, Jas Almamater) dan Sepatu PDH: Rp. 1.350.000,-[cite: 8]
* Asrama (Bulan Juli): Rp. 950.000,- khusus bagi siswa yang tinggal di asrama[cite: 8]

**Program Biaya Pendidikan Spesial:**
* **Bina Lingkungan:** Khusus bagi siswa yang berdomisili di Kota Salatiga, Kecamatan Tengaran, Kecamatan Suruh, dan Kecamatan Getasan[cite: 8]
* **Prestasi Akademik:** Khusus calon siswa dengan nilai rata-rata minimal 8.00 pada tiap semester 1-4 di tingkat SMP/MTs[cite: 8]

**Catatan Penting Daftar Ulang:**
* Biaya daftar ulang akan dikembalikan 100% apabila siswa tidak lulus SMP/MTs[cite: 8]
* Angsuran Partisipasi Pembangunan hangus apabila siswa membatalkan daftar ulang[cite: 8]
* Pelunasan biaya Partisipasi Pembangunan maksimal 3 bulan dari tanggal daftar ulang[cite: 8]
* Pengambilan seragam berlaku bagi siswa yang telah melunasi administrasi paling lambat akhir Oktober 2026[cite: 8]